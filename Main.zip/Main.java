package ejercicio;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		
		//ESTE PROGRAMA CALCULA LA CAPITAL DEL FOLCLORE NICARAGUENSE
		
		 Scanner lectordevariables = new Scanner(System.in);
		 String Pregunta = new String ("CUAL ES LA CAPITAL del FOLKLORE DE NICARAGUA?");
		 String Respuestacorrecta = new String ("MASAYA");
		 Boolean Acierto = false;
		 
		 System.out.println(Pregunta);
		 
		 for(int i = 1; i <=  3; i++) 
		 {
			 
			 if (Acierto == false)
			 {
				 String RespuestaIngresada = new String();
			 
				 RespuestaIngresada = lectordevariables.nextLine();

				 if(Respuestacorrecta.equals(RespuestaIngresada))
				 {	
					 System.out.println("ACERTÓ RESPUESTA CORRECTA");
					 Acierto = true;
				 }
			 }
			 
		 }
		 
		 if (! Acierto)
		 {
			 System.out.println("NO ACERTÓ");
			 System.out.println("La respuesta correcta es: ");
			 System.out.println(Respuestacorrecta);
		 }		
	}
}

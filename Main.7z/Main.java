package ejercicio59;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		int numeroevaluado, suma = 0;
		
		//Lectura de variable
		Scanner lectorvariable = new Scanner(System.in);
		System.out.println("Introduce el número a evaluar:");
		numeroevaluado = lectorvariable.nextInt();
		
		for (int i = 1; i < numeroevaluado; i++) 
		{
			if( numeroevaluado % i == 0)
			{
				suma = suma + i;
			}
		}
		
		if (suma == numeroevaluado)
		{
			System.out.println("El número es perfecto");
		}
		else
		{
			System.out.println("El número NO es perfecto");
		}	
		
		
	}

}

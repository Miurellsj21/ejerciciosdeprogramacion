package ejercicio;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//Elabore un programa que calcule los 20 primeros números de la serie de Fibonacci:	
				int Penultimo=0;
				int Ultimo=1;
				int Numerofibonacci;
				
				for(int i = 1; i <= 20; i++)
				{ 
					if(i==1)
					{		
						Numerofibonacci = Penultimo;
						System.out.println("Indice: "+i+" - Valorfibonacci: "+ Numerofibonacci);
					}
					
					else if(i==2) 
					{
						Numerofibonacci = Ultimo;
						System.out.println("Indice: "+i+" - Valorfibonacci: "+ Numerofibonacci);			
				    }
					
					else 
					{
						Numerofibonacci = Ultimo + Penultimo;
						System.out.println("Indice: "+i+" - Valorfibonacci: "+ Numerofibonacci);
						Penultimo = Ultimo;
					   Ultimo = Numerofibonacci;
					   
					}
				}
		}
}



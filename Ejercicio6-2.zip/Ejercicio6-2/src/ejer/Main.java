package ejer;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
int numeroevaluado, suma = 0;
		
		//Lectura de variable
		
		numeroevaluado = 1;
		System.out.println("hooo");
		
		int encontrados = 0;
		
		while(encontrados < 3) {
			
			suma = 0;
			
			for (int i = 1; i < numeroevaluado; i++) 
			{
				if( numeroevaluado % i == 0)
				{
					suma += i;
				}
			}
			
			if (suma == numeroevaluado)
			{
				System.out.println("Se encontró " + numeroevaluado + " como número perfecto");
				encontrados++;
			}
			
			
			numeroevaluado++;
		}
		
		
		
		
	}

}
